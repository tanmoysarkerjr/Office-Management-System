
import './App.css'

function App() {

  return (
   <div>
    <h2 className='text-4xl font-extrabold text-red-500'>welcome</h2>
   </div>
  )
}

export default App
